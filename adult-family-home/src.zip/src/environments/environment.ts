export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDABajs8rbYwBKsW74SRQbGQKyJ_GdU1tY",
  authDomain: "afhdynamicwebsite.firebaseapp.com",
  projectId: "afhdynamicwebsite",
  storageBucket: "afhdynamicwebsite.appspot.com",
  messagingSenderId: "692885221546",
  appId: "1:692885221546:web:23317a318f6e277a0520d3",
  measurementId: "G-JREGNTXHB6"
  },
  googleMapsApiKey: 'AIzaSyCz4F7dRDEir2krVB8HvALNq-HhRdqqvK4',
  useMockGoogleReviews: true,
  useMockGoogleMap: true
}
