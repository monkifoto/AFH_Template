import { IntakeForm } from './intake-form.model';

describe('IntakeForm', () => {
  it('should create an instance', () => {
    expect(new IntakeForm()).toBeTruthy();
  });
});
