import { Section } from './section.model';

describe('Section', () => {
  it('should create an instance', () => {
    expect(new Section()).toBeTruthy();
  });
});
