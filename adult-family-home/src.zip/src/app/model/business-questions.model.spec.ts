import { BusinessQuestions } from './business-questions.model';

describe('BusinessQuestions', () => {
  it('should create an instance', () => {
    expect(new BusinessQuestions()).toBeTruthy();
  });
});
