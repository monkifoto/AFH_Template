import { Component } from '@angular/core';

@Component({
    selector: 'app-parallax-text',
    templateUrl: './parallax-text.component.html',
    styleUrls: ['./parallax-text.component.css'],
    standalone: false
})
export class ParallaxTextComponent {

}
