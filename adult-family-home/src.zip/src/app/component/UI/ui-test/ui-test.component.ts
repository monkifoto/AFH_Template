import { Component } from '@angular/core';

@Component({
    selector: 'app-ui-test',
    templateUrl: './ui-test.component.html',
    styleUrls: ['./ui-test.component.css'],
    standalone: false
})
export class UiTestComponent {

}
