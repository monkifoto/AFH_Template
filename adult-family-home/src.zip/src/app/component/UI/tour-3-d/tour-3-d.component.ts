import { Component } from '@angular/core';

@Component({
    selector: 'app-tour-3-d',
    templateUrl: './tour-3-d.component.html',
    styleUrls: ['./tour-3-d.component.css'],
    standalone: false
})
export class Tour3DComponent {

}
