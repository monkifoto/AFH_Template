import { SplitCommaPipe } from './split-comma.pipe';

describe('SplitCommaPipe', () => {
  it('create an instance', () => {
    const pipe = new SplitCommaPipe();
    expect(pipe).toBeTruthy();
  });
});
