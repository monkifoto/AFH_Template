import { ReplaceKeywordPipe } from './replace-keyword.pipe';

describe('ReplaceKeywordPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceKeywordPipe();
    expect(pipe).toBeTruthy();
  });
});
