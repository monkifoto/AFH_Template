import { SectionFilterPipe } from './section-filter.pipe';

describe('SectionFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SectionFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
